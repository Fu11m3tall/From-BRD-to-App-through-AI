from django.shortcuts import render

# Create your views here.
def brd(request):
    return render(request, 'frontend/brd.html')