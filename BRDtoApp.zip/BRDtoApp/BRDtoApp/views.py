from django.http import HttpResponse
from django.shortcuts import render

def home(request):
    #return HttpResponse("Hello, World. You are all noobs at Home page")
    return render(request, 'website/index.html')

def about(request):
    #return HttpResponse("Hello, World. You are all noobs at About page")
    return render(request, 'website/about.html')

def contact(request):
    #return HttpResponse("Hello, World. You are all noobs at Contact page")
    return render(request, 'website/contact.html')

def services(request):
    #return HttpResponse("Hello, World. You are all noobs at Services page")
    return render(request, 'website/services.html')





